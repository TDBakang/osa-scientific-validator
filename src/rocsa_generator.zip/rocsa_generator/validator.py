"""Moteur de validation des définitions et contrôles ROCSA."""

from pathlib import Path
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
import yaml

from rocsa_generator.exceptions import ValidationError
from rocsa_generator.logger import get_logger
from rocsa_generator.models import GenerationRequest

logger = get_logger("validator")


class ValidationIssue(BaseModel):
    """Représente une erreur ou un avertissement de validation."""

    level: str = Field(..., description="'ERROR' ou 'WARNING'")
    message: str
    field: Optional[str] = None


class ValidationReport(BaseModel):
    """Rapport global produit après la validation d'une définition."""

    is_valid: bool
    file_path: Optional[str] = None
    issues: List[ValidationIssue] = Field(default_factory=list)

    @property
    def has_errors(self) -> bool:
        return any(issue.level == "ERROR" for issue in self.issues)

    @property
    def has_warnings(self) -> bool:
        return any(issue.level == "WARNING" for issue in self.issues)


class RocsaValidator:
    """Moteur de validation de la conformité des schémas et des règles métiers ROCSA."""

    def __init__(self, strict: bool = False):
        self.strict = strict

    def validate_file(self, file_path: Path) -> ValidationReport:
        """Charge et valide un fichier de définition YAML ou JSON."""
        if not file_path.exists():
            return ValidationReport(
                is_valid=False,
                file_path=str(file_path),
                issues=[ValidationIssue(level="ERROR", message=f"Fichier introuvable : {file_path}")],
            )

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                raw_data = yaml.safe_load(f)
        except Exception as e:
            return ValidationReport(
                is_valid=False,
                file_path=str(file_path),
                issues=[ValidationIssue(level="ERROR", message=f"Erreur de parsing YAML/JSON : {e}")],
            )

        if not isinstance(raw_data, dict):
            return ValidationReport(
                is_valid=False,
                file_path=str(file_path),
                issues=[ValidationIssue(level="ERROR", message="Le contenu de la définition doit être un objet/dictionnaire.")],
            )

        report = self.validate_dict(raw_data)
        report.file_path = str(file_path)
        return report

    def validate_dict(self, data: Dict[str, Any]) -> ValidationReport:
        """Effectue l'analyse syntaxique et les contrôles sémantiques sur un dictionnaire."""
        issues: List[ValidationIssue] = []

        # 1. Validation du schéma via Pydantic
        try:
            GenerationRequest(**data)
        except Exception as e:
            issues.append(
                ValidationIssue(
                    level="ERROR",
                    message=f"Échec du schéma Pydantic : {e}",
                )
            )

        # 2. Validation des règles métier / sémantiques spécifiques à ROCSA
        issues.extend(self._check_semantic_rules(data))

        # En mode strict, les avertissements sont considérés comme bloquants
        if self.strict:
            has_blocking_issue = len(issues) > 0
        else:
            has_blocking_issue = any(issue.level == "ERROR" for issue in issues)

        is_valid = not has_blocking_issue
        logger.info(f"Validation terminée : valide={is_valid}, {len(issues)} problème(s) trouvé(s)")

        return ValidationReport(is_valid=is_valid, issues=issues)

    def _check_semantic_rules(self, data: Dict[str, Any]) -> List[ValidationIssue]:
        """Contrôles sémantiques et règles de nommage personnalisées."""
        issues: List[ValidationIssue] = []

        # Exemple : Vérification de la convention de nommage
        name = data.get("name", "")
        if name and not name.islower():
            issues.append(
                ValidationIssue(
                    level="WARNING",
                    field="name",
                    message="Il est recommandé d'utiliser des minuscules pour le champ 'name'.",
                )
            )

        # Exemple : Vérification de présence de paramètres si requis
        params = data.get("parameters", {})
        if not params:
            issues.append(
                ValidationIssue(
                    level="WARNING",
                    field="parameters",
                    message="Le dictionnaire de paramètres est vide.",
                )
            )

        return issues