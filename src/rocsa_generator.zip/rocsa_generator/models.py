"""Data models and schemas for rocsa_generator."""

from datetime import datetime, timezone
from enum import Enum
from typing import Dict, Any, Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, ConfigDict


class OutputFormat(str, Enum):
    """Supported export target formats."""

    JSON = "json"
    YAML = "yaml"
    CSV = "csv"


class GenerationRequest(BaseModel):
    """Payload representing a single generation job request."""

    model_config = ConfigDict(frozen=True)

    request_id: UUID = Field(default_factory=uuid4)
    name: str = Field(..., min_length=1, max_length=120, description="Name of the payload")
    format: OutputFormat = Field(default=OutputFormat.JSON)
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Arbitrary parameters")


class GenerationResult(BaseModel):
    """Outcome payload after executing a generation job."""

    request_id: UUID
    success: bool
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    output_path: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)