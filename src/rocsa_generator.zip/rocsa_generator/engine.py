"""Moteur de génération et de validation ROCSA."""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
import yaml

from jinja2 import Environment, FileSystemLoader, TemplateError
from pydantic import ValidationError as PydanticValidationError

from rocsa_generator.config import settings
from rocsa_generator.exceptions import GenerationError, ValidationError
from rocsa_generator.logger import get_logger
from rocsa_generator.models import GenerationRequest, GenerationResult, OutputFormat

logger = get_logger("engine")


class RocsaEngine:
    """Moteur d'exécution pour la validation des définitions et la génération des artefacts ROCSA."""

    def __init__(
        self,
        templates_dir: Optional[Path] = None,
        output_dir: Optional[Path] = None,
    ):
        self.output_dir = output_dir or settings.output_dir
        self.templates_dir = templates_dir or (Path(__file__).parent / "templates")

        # Initialisation du moteur de rendu Jinja2 s'il existe un dossier de templates
        if self.templates_dir.exists():
            self.jinja_env = Environment(
                loader=FileSystemLoader(self.templates_dir),
                autoescape=False,
                trim_blocks=True,
                lstrip_blocks=True,
            )
        else:
            self.jinja_env = None
            logger.debug(f"Dossier de templates non trouvé : {self.templates_dir}")

    def load_definition(self, file_path: Path) -> Dict[str, Any]:
        """Charge et parse un fichier de définition YAML ou JSON."""
        if not file_path.exists():
            raise ValidationError(f"Fichier de définition introuvable : {file_path}")

        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
                logger.debug(f"Fichier chargé avec succès depuis {file_path}")
                return data or {}
        except Exception as e:
            raise ValidationError(
                f"Erreur lors de la lecture du fichier {file_path.name} : {e}"
            ) from e

    def validate_definition(self, raw_data: Dict[str, Any]) -> GenerationRequest:
        """Valide la structure d'une définition par rapport au modèle Pydantic GenerationRequest."""
        try:
            request = GenerationRequest(**raw_data)
            logger.info(f"Définition validée avec succès (ID: {request.request_id})")
            return request
        except PydanticValidationError as e:
            logger.error(f"Échec de validation du schéma : {e}")
            raise ValidationError(f"Schéma de définition invalide : {e}") from e

    def build_sdk(self, request: GenerationRequest) -> GenerationResult:
        """Génère le SDK ou les fichiers d'artefacts à partir d'une requête validée."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        target_path = self.output_dir / f"{request.name}.{request.format.value}"

        try:
            logger.info(f"Début de la génération pour : {request.name}")

            # Sérialisation selon le format configuré
            if request.format == OutputFormat.JSON:
                content = request.model_dump_json(indent=2)
            elif request.format == OutputFormat.YAML:
                content = yaml.dump(request.model_dump(), sort_keys=False)
            else:
                content = str(request.parameters)

            target_path.write_text(content, encoding="utf-8")
            logger.info(f"Artefact généré avec succès : {target_path}")

            return GenerationResult(
                request_id=request.request_id,
                success=True,
                output_path=str(target_path),
                metadata={
                    "format": request.format.value,
                    "bytes_written": len(content.encode("utf-8")),
                },
            )
        except Exception as e:
            logger.error(f"Erreur de génération pour '{request.name}' : {e}")
            raise GenerationError(f"Échec lors de la génération de l'artefact : {e}") from e

    def generate_registry(self, workspace_dir: Path) -> GenerationResult:
        """Scanne un espace de travail et compile un registre global (JSON)."""
        if not workspace_dir.exists():
            raise ValidationError(f"Dossier workspace introuvable : {workspace_dir}")

        definitions: List[Dict[str, Any]] = []
        yaml_files = list(workspace_dir.rglob("*.yaml")) + list(workspace_dir.rglob("*.yml"))

        for file_path in yaml_files:
            try:
                raw_data = self.load_definition(file_path)
                definitions.append(raw_data)
            except ValidationError as err:
                logger.warning(f"Fichier ignoré lors du scan du registre ({file_path.name}) : {err}")

        registry_path = self.output_dir / "registry.json"
        self.output_dir.mkdir(parents=True, exist_ok=True)

        try:
            registry_data = {
                "total_definitions": len(definitions),
                "items": definitions,
            }
            registry_path.write_text(json.dumps(registry_data, indent=2), encoding="utf-8")
            logger.info(f"Registre généré avec {len(definitions)} définitions.")

            return GenerationResult(
                request_id=GenerationRequest(name="registry").request_id,
                success=True,
                output_path=str(registry_path),
                metadata={"items_count": len(definitions)},
            )
        except Exception as e:
            raise GenerationError(f"Erreur de compilation du registre : {e}") from e