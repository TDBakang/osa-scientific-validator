"""
ROCSA Generator - Scientific Atomic Controls Generator.

Ce paquet fournit la suite d'outils et de compilateurs pour la validation,
l'indexation et la génération de contrôles scientifiques ROCSA.
"""

__version__ = "0.1.0"
__author__ = "OSA Scientific Committee"

from rocsa_generator.config import Settings, settings
from rocsa_generator.engine import RocsaEngine
from rocsa_generator.exceptions import (
    ConfigurationError,
    GenerationError,
    RocsaGeneratorError,
    ValidationError,
)
from rocsa_generator.logger import configure_logging, get_logger
from rocsa_generator.models import (
    GenerationRequest,
    GenerationResult,
    OutputFormat,
)
from rocsa_generator.registry import (
    RegistryEntry,
    RegistryIndex,
    RocsaRegistry,
)
from rocsa_generator.renderer import RocsaRenderer
from rocsa_generator.validator import (
    RocsaValidator,
    ValidationIssue,
    ValidationReport,
)

__all__ = [
    # Métadonnées
    "__version__",
    "__author__",
    # Moteurs principaux
    "RocsaEngine",
    "RocsaValidator",
    "RocsaRegistry",
    "RocsaRenderer",
    # Configuration & Logging
    "Settings",
    "settings",
    "get_logger",
    "configure_logging",
    # Modèles & Schémas
    "GenerationRequest",
    "GenerationResult",
    "OutputFormat",
    "ValidationIssue",
    "ValidationReport",
    "RegistryEntry",
    "RegistryIndex",
    # Exceptions
    "RocsaGeneratorError",
    "ConfigurationError",
    "ValidationError",
    "GenerationError",
]