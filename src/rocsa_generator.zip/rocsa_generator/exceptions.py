"""Custom exception hierarchy for rocsa_generator."""


class RocsaGeneratorError(Exception):
    """Base exception for all errors raised by rocsa_generator."""

    pass


class ConfigurationError(RocsaGeneratorError):
    """Raised when application configuration or settings are invalid."""

    pass


class ValidationError(RocsaGeneratorError):
    """Raised when data validation or domain constraints fail."""

    pass


class GenerationError(RocsaGeneratorError):
    """Raised when an error occurs during the core generation process."""

    pass