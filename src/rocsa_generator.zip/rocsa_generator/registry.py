"""Gestionnaire de registre et d'indexation des définitions ROCSA."""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
import yaml

from rocsa_generator.exceptions import GenerationError, ValidationError
from rocsa_generator.logger import get_logger
from rocsa_generator.validator import RocsaValidator

logger = get_logger("registry")


class RegistryEntry(BaseModel):
    """Métadonnées d'une entrée enregistrée dans le registre."""

    id: str = Field(..., description="Identifiant unique ou nom de la définition")
    file_path: str = Field(..., description="Chemin d'accès au fichier source")
    definition: Dict[str, Any] = Field(default_factory=dict, description="Contenu de la définition")
    is_valid: bool = Field(default=True, description="Statut de la validation")


class RegistryIndex(BaseModel):
    """Structure globale du registre exportable."""

    total_entries: int = 0
    entries: Dict[str, RegistryEntry] = Field(default_factory=dict)


class RocsaRegistry:
    """Gestionnaire central pour la recherche, l'enregistrement et l'export du registre ROCSA."""

    def __init__(self, workspace_path: Optional[Path] = None):
        self.workspace_path = workspace_path or Path.cwd()
        self.validator = RocsaValidator()
        self._index = RegistryIndex()

    @property
    def entries(self) -> Dict[str, RegistryEntry]:
        """Retourne les entrées actuellement chargées dans le registre."""
        return self._index.entries

    def register_file(self, file_path: Path) -> RegistryEntry:
        """Valide et enregistre un fichier de définition unique."""
        report = self.validator.validate_file(file_path)
        
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
        except Exception as e:
            raise ValidationError(f"Impossible de lire {file_path} : {e}") from e

        # Extrait l'identifiant (nom de la définition ou nom du fichier par défaut)
        entry_id = data.get("name") or file_path.stem

        entry = RegistryEntry(
            id=entry_id,
            file_path=str(file_path.resolve()),
            definition=data,
            is_valid=report.is_valid,
        )

        self._index.entries[entry_id] = entry
        self._index.total_entries = len(self._index.entries)

        logger.info(f"Entrée enregistrée : {entry_id} (valide={report.is_valid})")
        return entry

    def scan_workspace(self, target_dir: Optional[Path] = None) -> RegistryIndex:
        """Scanne récursivement un dossier à la recherche de fichiers YAML/JSON et construit l'index."""
        scan_dir = target_dir or self.workspace_path
        if not scan_dir.exists():
            raise ValidationError(f"Le dossier à scanner n'existe pas : {scan_dir}")

        logger.info(f"Début du scan du registre dans : {scan_dir}")
        self._index = RegistryIndex()  # Réinitialisation de l'index

        files = list(scan_dir.rglob("*.yaml")) + list(scan_dir.rglob("*.yml")) + list(scan_dir.rglob("*.json"))
        
        # Exclure d'éventuels fichiers de registre préexistants
        files = [f for f in files if f.name != "registry.json"]

        for file_path in files:
            try:
                self.register_file(file_path)
            except ValidationError as err:
                logger.warning(f"Fichier ignoré lors du scan ({file_path.name}) : {err}")

        logger.info(f"Scan terminé. {self._index.total_entries} entrée(s) indexée(s).")
        return self._index

    def get_entry(self, entry_id: str) -> Optional[RegistryEntry]:
        """Récupère une entrée du registre par son identifiant."""
        return self._index.entries.get(entry_id)

    def export(self, output_path: Path) -> None:
        """Exporte l'index du registre au format JSON."""
        output_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            content = self._index.model_dump_json(indent=2)
            output_path.write_text(content, encoding="utf-8")
            logger.info(f"Registre exporté avec succès vers : {output_path}")
        except Exception as e:
            raise GenerationError(f"Échec de l'export du registre vers {output_path} : {e}") from e

    def load_from_json(self, json_path: Path) -> None:
        """Charge un registre existant depuis un fichier JSON."""
        if not json_path.exists():
            raise ValidationError(f"Fichier de registre introuvable : {json_path}")
        try:
            content = json_path.read_text(encoding="utf-8")
            self._index = RegistryIndex.model_validate_json(content)
            logger.info(f"Registre chargé depuis {json_path} ({self._index.total_entries} entrées)")
        except Exception as e:
            raise ValidationError(f"Erreur lors du chargement du registre : {e}") from e